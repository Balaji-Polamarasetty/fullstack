# Quizzy — Online Quiz Application

A responsive frontend mini-project built using **HTML5, CSS3 and React.js**. No backend or database is used.

## Features
- Three categories: Web Development, JavaScript Basics and General Knowledge
- 10 multiple-choice questions per category
- Countdown timer with automatic submission when time runs out
- Previous/next navigation and clickable question map
- Progress indicator and answered-question count
- Score summary, correct/incorrect counts and review explanations
- Attempt history and personal best saved in browser `localStorage`
- Responsive desktop, tablet and mobile design

## Run locally
Install Node.js LTS, then in this folder run:

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal (usually http://localhost:5173).

Build for production:
```bash
npm run build
npm run preview
```

## Project structure
```text
online-quiz-application/
├── index.html
├── package.json
├── README.md
├── .gitignore
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── data.js
    └── styles.css
```

## Push to GitHub
Create an empty repository on GitHub, then run these commands in the project folder:

```bash
git init
git add .
git commit -m "Build Quizzy online quiz application"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/online-quiz-application.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username and use the repository URL shown by GitHub.

## Deploy (optional)
Import the repository into Vercel or Netlify. Build command: `npm run build`; output folder: `dist`.

## Limitations
Quiz questions are stored in `src/data.js`, and result history is stored in the current browser's `localStorage`. Data does not sync between users/devices. There is no secure login, backend, or admin panel because the project is frontend-only.
